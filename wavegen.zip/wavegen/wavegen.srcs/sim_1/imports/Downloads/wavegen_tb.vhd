
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
use work.wave_package.ALL;

entity wavegen_tb is
end wavegen_tb;

architecture behavior of wavegen_tb is

    -- Component declaration
    component wavegen is
        port(
            clock    : in  std_logic;
            reset    : in  std_logic;
            enable   : in  std_logic;
            wave_sel : in  std_logic_vector(1 downto 0);
            JA       : out std_logic_vector(data_bits - 1 downto 0);
            sine_out : out std_logic_vector(data_bits - 1 downto 0)
        );
    end component;

    -- Testbench signals
    signal clock    : std_logic := '0';
    signal reset    : std_logic := '1';
    signal enable   : std_logic := '0';
    signal wave_sel : std_logic_vector(1 downto 0) := "00";

    signal JA       : std_logic_vector(data_bits - 1 downto 0);
    signal sine_out : std_logic_vector(data_bits - 1 downto 0);

    -- Clock period
    constant clock_period : time := 100 ns;

    -- Expected sine table
    constant sine_table_tb : rom_type := sine_rom;

    -- Triangle wave constants
    constant output_max : integer := (2**data_bits) - 1;
    constant half_range : integer := max_address / 2;

begin

    -- Unit under test
    uut: wavegen
        port map(
            clock    => clock,
            reset    => reset,
            enable   => enable,
            wave_sel => wave_sel,
            JA       => JA,
            sine_out => sine_out
        );

    -- Clock generation
    clock_process: process
    begin
        clock <= '0';
        wait for clock_period / 2;
        clock <= '1';
        wait for clock_period / 2;
    end process;

    -- Main test process
    stimulus_process: process
        variable expected_value : integer;
    begin

        --------------------------------------------------
        -- INITIAL RESET
        --------------------------------------------------
        reset <= '1';
        enable <= '0';
        wave_sel <= "00";

        wait until rising_edge(clock);
        wait for 1 ns;

        reset <= '0';
        enable <= '1';

        --------------------------------------------------
        -- TEST 1: SINE WAVE
        -- wave_sel = 00
        --------------------------------------------------
        report "Starting SINE wave test";

        wave_sel <= "00";

        for i in 0 to max_address loop

            wait until rising_edge(clock);
            wait for 1 ns;

            assert JA = std_logic_vector(sine_table_tb(i))
                report "SINE wave error at address " & integer'image(i)
                severity failure;

            assert sine_out = JA
                report "SINE output does not match JA"
                severity failure;

        end loop;

        report "SINE wave test PASSED";

        --------------------------------------------------
        -- TEST 2: SQUARE WAVE
        -- wave_sel = 01
        --------------------------------------------------
        reset <= '1';
        enable <= '0';

        wait until rising_edge(clock);
        wait for 1 ns;

        reset <= '0';
        enable <= '1';
        wave_sel <= "01";

        report "Starting SQUARE wave test";

        for i in 0 to max_address loop

            wait until rising_edge(clock);
            wait for 1 ns;

            if i <= half_range then
                assert JA = x"FF"
                    report "SQUARE wave should be HIGH at address "
                    & integer'image(i)
                    severity failure;
            else
                assert JA = x"00"
                    report "SQUARE wave should be LOW at address "
                    & integer'image(i)
                    severity failure;
            end if;

            assert sine_out = JA
                report "SINE output does not match JA"
                severity failure;

        end loop;

        report "SQUARE wave test PASSED";

        --------------------------------------------------
        -- TEST 3: TRIANGLE WAVE
        -- wave_sel = 10
        --------------------------------------------------
        reset <= '1';
        enable <= '0';

        wait until rising_edge(clock);
        wait for 1 ns;

        reset <= '0';
        enable <= '1';
        wave_sel <= "10";

        report "Starting TRIANGLE wave test";

        for i in 0 to max_address loop

            wait until rising_edge(clock);
            wait for 1 ns;

            if i <= half_range then
                expected_value := (i * output_max) / half_range;
            else
                expected_value :=
                    ((max_address - i) * output_max) / half_range;
            end if;

            assert JA = std_logic_vector(
                to_unsigned(expected_value, data_bits)
            )
                report "TRIANGLE wave error at address "
                & integer'image(i)
                severity failure;

            assert sine_out = JA
                report "SINE output does not match JA"
                severity failure;

        end loop;

        report "TRIANGLE wave test PASSED";

        --------------------------------------------------
        -- TEST 4: ZERO OUTPUT
        -- wave_sel = 11
        --------------------------------------------------
        reset <= '1';
        enable <= '0';

        wait until rising_edge(clock);
        wait for 1 ns;

        reset <= '0';
        enable <= '1';
        wave_sel <= "11";

        report "Starting ZERO output test";

        for i in 0 to max_address loop

            wait until rising_edge(clock);
            wait for 1 ns;

            assert JA = x"00"
                report "ZERO output error at address "
                & integer'image(i)
                severity failure;

            assert sine_out = JA
                report "SINE output does not match JA"
                severity failure;

        end loop;

        report "ZERO output test PASSED";

        --------------------------------------------------
        -- FINISH SIMULATION
        --------------------------------------------------
        enable <= '0';

        report "ALL FOUR WAVEFORM TESTS PASSED!"
            severity note;

        wait;

    end process;

end behavior;
