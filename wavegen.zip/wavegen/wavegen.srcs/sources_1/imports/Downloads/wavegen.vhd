library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

-- Include the wave_package
use work.wave_package.all;

entity wavegen is
    port(
        clock, reset, enable : in std_logic;
        wave_sel : in std_logic_vector(1 downto 0);

        JA       : out std_logic_vector(data_bits - 1 downto 0)
    );
end wavegen;

architecture arch1 of wavegen is

    -- Address counter
    signal addr : integer range 0 to max_address;

    -- Sine ROM
    signal sine_table : rom_type;

    -- Waveform signals
    signal sine_vector   : std_logic_vector(data_bits - 1 downto 0);
    signal square_wave   : std_logic_vector(data_bits - 1 downto 0);
    signal triangle_wave : std_logic_vector(data_bits - 1 downto 0);
    signal selected_wave : std_logic_vector(data_bits - 1 downto 0);

begin

    -- Load sine ROM
    sine_table <= sine_rom;

    -- Generate sine, square, and triangle waveforms
    process(clock)

        variable triangle_value : integer;

        constant output_max : integer := (2**data_bits) - 1;
        constant half_range : integer := max_address / 2;

    begin

        if (reset = '1') then

            sine_vector   <= (others => '0');
            square_wave   <= (others => '0');
            triangle_wave <= (others => '0');
            addr <= 0;

        elsif (rising_edge(clock)) then

            if (enable = '1') then

                -- Sine wave generation
                sine_vector <= std_logic_vector(sine_table(addr));

                -- Square wave generation
                if (addr <= half_range) then
                    square_wave <= (others => '1');
                else
                    square_wave <= (others => '0');
                end if;

                -- Triangle wave generation
                if (addr <= half_range) then

                    triangle_value :=
                        (addr * output_max) / half_range;

                else

                    triangle_value :=
                        ((max_address - addr) * output_max) / half_range;

                end if;

                triangle_wave <= std_logic_vector(
                    to_unsigned(triangle_value, data_bits)
                );

                -- Address counter
                if (addr = max_address) then
                    addr <= 0;
                else
                    addr <= addr + 1;
                end if;

            end if;

        end if;

    end process;

    -- Select waveform using wave_sel
    process(wave_sel, sine_vector, square_wave, triangle_wave)

    begin

        case wave_sel is

            when "00" =>
                selected_wave <= sine_vector;

            when "01" =>
                selected_wave <= square_wave;

            when "10" =>
                selected_wave <= triangle_wave;

            when "11" =>
                selected_wave <= (others => '0');

            when others =>
                selected_wave <= (others => '0');

        end case;

    end process;

    -- Send selected waveform to both outputs
    JA <= selected_wave;

end arch1;

